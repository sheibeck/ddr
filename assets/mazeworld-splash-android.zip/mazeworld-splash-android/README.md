# Mazeworld Android splash assets

The supplied splash artwork has been center-cropped by less than 0.1% to an exact 9:16 frame, resized with Lanczos filtering, stripped of metadata, and encoded as lossy WebP at quality 84.

| Android bucket | Scale | Pixel dimensions | Resource path |
| --- | ---: | ---: | --- |
| mdpi | 1x | 360 × 640 | `drawable-mdpi/splash_screen.webp` |
| hdpi | 1.5x | 540 × 960 | `drawable-hdpi/splash_screen.webp` |
| xhdpi | 2x | 720 × 1280 | `drawable-xhdpi/splash_screen.webp` |
| xxhdpi | 3x | 1080 × 1920 | `drawable-xxhdpi/splash_screen.webp` |
| xxxhdpi | 4x | 1440 × 2560 | `drawable-xxxhdpi/splash_screen.webp` |

Copy the five `drawable-*` folders into `android/app/src/main/res/`. Reference the image as `@drawable/splash_screen`.

The original attachment is 941 × 1672, so the `xxhdpi` and `xxxhdpi` variants require upscaling. Android will still select the correct resource without runtime scaling between density buckets, but those two files cannot gain detail absent from the source.

For Android 12 and newer, the system-controlled launch splash normally displays an app icon over a solid background. Use these full-screen images for the app's branded splash view immediately after that system splash, or with a compatible splash-screen library.
